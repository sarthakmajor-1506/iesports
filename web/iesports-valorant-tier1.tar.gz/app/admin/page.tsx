"use client";

import { useState } from "react";
import Navbar from "@/app/components/Navbar";

export default function AdminPanel() {
  const [adminKey, setAdminKey] = useState("");
  const [authenticated, setAuthenticated] = useState(false);
  const [tournamentId, setTournamentId] = useState("valorant-shuffle-test-mar28");
  const [log, setLog] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  // Match result form
  const [matchId, setMatchId] = useState("");
  const [t1Score, setT1Score] = useState("0");
  const [t2Score, setT2Score] = useState("0");

  // Lobby form
  const [lobbyMatchId, setLobbyMatchId] = useState("");
  const [lobbyName, setLobbyName] = useState("");
  const [lobbyPassword, setLobbyPassword] = useState("");

  // Shuffle
  const [teamCount, setTeamCount] = useState("2");

  // Pairings
  const [matchDay, setMatchDay] = useState("1");

  // Substitute
  const [subTeamId, setSubTeamId] = useState("");
  const [subOldUid, setSubOldUid] = useState("");
  const [subNewUid, setSubNewUid] = useState("");

  const addLog = (msg: string) => setLog(prev => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev]);

  const apiCall = async (endpoint: string, body: any) => {
    setLoading(true);
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...body, adminKey }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      addLog(`✅ ${endpoint}: ${JSON.stringify(data).slice(0, 200)}`);
      return data;
    } catch (e: any) {
      addLog(`❌ ${endpoint}: ${e.message}`);
      throw e;
    } finally {
      setLoading(false);
    }
  };

  if (!authenticated) {
    return (
      <>
        <style>{`
          .admin-login { min-height: 100vh; background: #F8F7F4; display: flex; align-items: center; justify-content: center; font-family: system-ui, sans-serif; }
          .admin-login-box { background: #fff; border: 1px solid #E5E3DF; border-radius: 16px; padding: 40px; max-width: 400px; width: 100%; text-align: center; }
        `}</style>
        <div className="admin-login">
          <div className="admin-login-box">
            <h1 style={{ fontSize: "1.4rem", fontWeight: 900, marginBottom: 8 }}>Admin Panel</h1>
            <p style={{ fontSize: "0.85rem", color: "#888", marginBottom: 24 }}>Enter the admin key to access tournament management.</p>
            <input
              type="password"
              placeholder="Admin Key"
              value={adminKey}
              onChange={e => setAdminKey(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && adminKey) setAuthenticated(true); }}
              style={{ width: "100%", padding: 12, border: "1.5px solid #E5E3DF", borderRadius: 10, fontSize: "0.95rem", marginBottom: 12, outline: "none", boxSizing: "border-box" }}
            />
            <button
              onClick={() => { if (adminKey) setAuthenticated(true); }}
              style={{ width: "100%", padding: 12, background: "#ff4655", color: "#fff", border: "none", borderRadius: 100, fontWeight: 700, fontSize: "0.95rem", cursor: "pointer" }}
            >
              Authenticate →
            </button>
          </div>
        </div>
      </>
    );
  }

  const sectionStyle: React.CSSProperties = { background: "#fff", border: "1px solid #E5E3DF", borderRadius: 14, padding: "20px 24px", marginBottom: 16 };
  const labelStyle: React.CSSProperties = { display: "block", fontSize: "0.62rem", fontWeight: 800, letterSpacing: "0.12em", textTransform: "uppercase" as const, color: "#bbb", marginBottom: 14 };
  const inputStyle: React.CSSProperties = { width: "100%", padding: 10, border: "1.5px solid #E5E3DF", borderRadius: 8, fontSize: "0.88rem", outline: "none", boxSizing: "border-box" as const, marginBottom: 8 };
  const btnStyle: React.CSSProperties = { padding: "10px 20px", background: "#ff4655", color: "#fff", border: "none", borderRadius: 100, fontWeight: 700, fontSize: "0.82rem", cursor: "pointer", opacity: loading ? 0.6 : 1 };
  const btnSecondary: React.CSSProperties = { ...btnStyle, background: "#111" };

  return (
    <>
      <style>{`
        .adm-page { min-height: 100vh; background: #F8F7F4; font-family: var(--font-geist-sans), system-ui, sans-serif; }
        .adm-content { max-width: 800px; margin: 0 auto; padding: 20px 24px 60px; }
        .adm-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        @media (max-width: 700px) { .adm-grid { grid-template-columns: 1fr; } }
        .adm-log { background: #111; border-radius: 10px; padding: 14px; max-height: 250px; overflow-y: auto; font-family: monospace; font-size: 0.72rem; color: #aaa; line-height: 1.8; }
      `}</style>

      <div className="adm-page">
        <Navbar />
        <div className="adm-content">
          <h1 style={{ fontSize: "1.4rem", fontWeight: 900, marginBottom: 4 }}>Tournament Admin</h1>
          <p style={{ fontSize: "0.82rem", color: "#888", marginBottom: 20 }}>Manage your Valorant tournament</p>

          {/* Tournament ID selector */}
          <div style={sectionStyle}>
            <span style={labelStyle}>Tournament ID</span>
            <input value={tournamentId} onChange={e => setTournamentId(e.target.value)} style={inputStyle} />
          </div>

          <div className="adm-grid">
            {/* Shuffle Teams */}
            <div style={sectionStyle}>
              <span style={labelStyle}>1. Shuffle Teams</span>
              <input value={teamCount} onChange={e => setTeamCount(e.target.value)} placeholder="Number of teams" style={inputStyle} type="number" min="2" />
              <button disabled={loading} style={btnStyle} onClick={() => apiCall("/api/valorant/shuffle-teams", { tournamentId, teamCount: parseInt(teamCount) })}>
                Shuffle Teams
              </button>
            </div>

            {/* Generate Pairings */}
            <div style={sectionStyle}>
              <span style={labelStyle}>2. Generate Swiss Pairings</span>
              <input value={matchDay} onChange={e => setMatchDay(e.target.value)} placeholder="Match Day (1-5)" style={inputStyle} type="number" min="1" max="5" />
              <button disabled={loading} style={btnStyle} onClick={() => apiCall("/api/valorant/swiss-pairings", { tournamentId, matchDay: parseInt(matchDay) })}>
                Generate Pairings
              </button>
            </div>

            {/* Set Lobby Info */}
            <div style={sectionStyle}>
              <span style={labelStyle}>3. Set Lobby Info</span>
              <input value={lobbyMatchId} onChange={e => setLobbyMatchId(e.target.value)} placeholder="Match ID (e.g. day1-match1)" style={inputStyle} />
              <input value={lobbyName} onChange={e => setLobbyName(e.target.value)} placeholder="Lobby Name" style={inputStyle} />
              <input value={lobbyPassword} onChange={e => setLobbyPassword(e.target.value)} placeholder="Password" style={inputStyle} />
              <div style={{ display: "flex", gap: 8 }}>
                <button disabled={loading} style={btnStyle} onClick={() => apiCall("/api/valorant/match-update", { tournamentId, matchId: lobbyMatchId, action: "set-lobby", lobbyName, lobbyPassword })}>
                  Set Lobby
                </button>
                <button disabled={loading} style={btnSecondary} onClick={() => apiCall("/api/valorant/match-update", { tournamentId, matchId: lobbyMatchId, action: "start" })}>
                  Start Match
                </button>
              </div>
            </div>

            {/* Submit Result */}
            <div style={sectionStyle}>
              <span style={labelStyle}>4. Submit Match Result</span>
              <input value={matchId} onChange={e => setMatchId(e.target.value)} placeholder="Match ID (e.g. day1-match1)" style={inputStyle} />
              <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
                <input value={t1Score} onChange={e => setT1Score(e.target.value)} placeholder="Team 1" style={{ ...inputStyle, textAlign: "center" as const }} type="number" min="0" max="2" />
                <span style={{ display: "flex", alignItems: "center", color: "#999", fontWeight: 700 }}>vs</span>
                <input value={t2Score} onChange={e => setT2Score(e.target.value)} placeholder="Team 2" style={{ ...inputStyle, textAlign: "center" as const }} type="number" min="0" max="2" />
              </div>
              <button disabled={loading} style={btnStyle} onClick={() => apiCall("/api/valorant/match-result", { tournamentId, matchId, team1Score: parseInt(t1Score), team2Score: parseInt(t2Score) })}>
                Submit Result
              </button>
            </div>

            {/* Substitute Player */}
            <div style={sectionStyle}>
              <span style={labelStyle}>5. Substitute Player</span>
              <input value={subTeamId} onChange={e => setSubTeamId(e.target.value)} placeholder="Team ID (e.g. team-1)" style={inputStyle} />
              <input value={subOldUid} onChange={e => setSubOldUid(e.target.value)} placeholder="Old Player UID" style={inputStyle} />
              <input value={subNewUid} onChange={e => setSubNewUid(e.target.value)} placeholder="New Player UID" style={inputStyle} />
              <button disabled={loading} style={btnStyle} onClick={() => apiCall("/api/valorant/substitute", { tournamentId, teamId: subTeamId, oldPlayerUid: subOldUid, newPlayerUid: subNewUid })}>
                Substitute
              </button>
            </div>
          </div>

          {/* Log */}
          <div style={{ ...sectionStyle, marginTop: 8 }}>
            <span style={labelStyle}>Activity Log</span>
            <div className="adm-log">
              {log.length === 0 ? (
                <span style={{ color: "#555" }}>No actions yet. Use the controls above.</span>
              ) : (
                log.map((l, i) => <div key={i}>{l}</div>)
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
