import { NextRequest, NextResponse } from "next/server";
import { adminDb } from "@/lib/firebaseAdmin";

/**
 * Fetches match details from Henrik API v4 and stores player stats.
 * Admin enters a Valorant match ID, system pulls all player stats.
 *
 * Henrik API endpoint: GET /valorant/v4/match/{region}/{platform}/{matchId}
 * Fallback to v3: GET /valorant/v3/match/{matchId} (if v4 fails)
 */
export async function POST(req: NextRequest) {
  try {
    const { tournamentId, adminKey, matchDocId, valorantMatchId, region } = await req.json();

    if (!tournamentId || !adminKey || !matchDocId || !valorantMatchId) {
      return NextResponse.json({ error: "Missing fields: tournamentId, adminKey, matchDocId, valorantMatchId required" }, { status: 400 });
    }
    if (adminKey !== process.env.ADMIN_SECRET) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const henrikKey = process.env.HENRIK_API_KEY;
    if (!henrikKey) {
      return NextResponse.json({ error: "HENRIK_API_KEY not configured" }, { status: 500 });
    }

    // ── Fetch match from Henrik API ──────────────────────────────────────────
    const matchRegion = region || "ap";
    const platform = "pc";

    // Try v4 first, fallback to v3
    let matchData: any = null;
    let apiVersion = "v4";

    try {
      const v4Url = `https://api.henrikdev.xyz/valorant/v4/match/${matchRegion}/${platform}/${valorantMatchId}`;
      const v4Res = await fetch(v4Url, {
        headers: { Authorization: henrikKey },
      });

      if (v4Res.ok) {
        const v4Data = await v4Res.json();
        matchData = v4Data.data;
      } else {
        throw new Error(`v4 returned ${v4Res.status}`);
      }
    } catch {
      // Fallback to v3
      apiVersion = "v3";
      const v3Url = `https://api.henrikdev.xyz/valorant/v3/match/${valorantMatchId}`;
      const v3Res = await fetch(v3Url, {
        headers: { Authorization: henrikKey },
      });

      if (!v3Res.ok) {
        return NextResponse.json({ error: `Henrik API error: ${v3Res.status}. Match ID may be invalid.` }, { status: 400 });
      }

      const v3Data = await v3Res.json();
      matchData = v3Data.data;
    }

    if (!matchData) {
      return NextResponse.json({ error: "Could not fetch match data from Henrik API" }, { status: 400 });
    }

    // ── Parse player stats ───────────────────────────────────────────────────
    let playerStats: any[] = [];
    let mapName = "";
    let roundsPlayed = 0;
    let team1Rounds = 0;
    let team2Rounds = 0;

    if (apiVersion === "v4") {
      // v4 format
      mapName = matchData.metadata?.map?.name || "Unknown";
      roundsPlayed = (matchData.teams?.red?.rounds_won || 0) + (matchData.teams?.blue?.rounds_won || 0);
      team1Rounds = matchData.teams?.red?.rounds_won || 0;
      team2Rounds = matchData.teams?.blue?.rounds_won || 0;

      playerStats = (matchData.players || []).map((p: any) => ({
        puuid: p.puuid,
        name: p.name,
        tag: p.tag,
        team: p.team_id, // "Red" or "Blue"
        agent: p.agent?.name || "Unknown",
        kills: p.stats?.kills || 0,
        deaths: p.stats?.deaths || 0,
        assists: p.stats?.assists || 0,
        score: p.stats?.score || 0,
        headshots: p.stats?.headshots || 0,
        bodyshots: p.stats?.bodyshots || 0,
        legshots: p.stats?.legshots || 0,
        damageDealt: p.stats?.damage?.dealt || 0,
        damageReceived: p.stats?.damage?.received || 0,
      }));
    } else {
      // v3 format (slightly different structure)
      const allPlayers = matchData.players?.all_players || [];
      mapName = matchData.metadata?.map || "Unknown";
      roundsPlayed = matchData.metadata?.rounds_played || 0;

      // Get team round scores from teams data
      team1Rounds = matchData.teams?.red?.rounds_won || 0;
      team2Rounds = matchData.teams?.blue?.rounds_won || 0;

      playerStats = allPlayers.map((p: any) => ({
        puuid: p.puuid,
        name: p.name,
        tag: p.tag,
        team: p.team, // "Red" or "Blue"
        agent: p.character || "Unknown",
        kills: p.stats?.kills || 0,
        deaths: p.stats?.deaths || 0,
        assists: p.stats?.assists || 0,
        score: p.stats?.score || 0,
        headshots: p.stats?.headshots || 0,
        bodyshots: p.stats?.bodyshots || 0,
        legshots: p.stats?.legshots || 0,
        damageDealt: p.damage_made || 0,
        damageReceived: p.damage_received || 0,
      }));
    }

    // ── Store match stats in Firestore ────────────────────────────────────────
    const tournamentRef = adminDb.collection("valorantTournaments").doc(tournamentId);

    // Update the match doc with Valorant match ID and map info
    const matchRef = tournamentRef.collection("matches").doc(matchDocId);
    const matchDoc = await matchRef.get();

    if (!matchDoc.exists) {
      return NextResponse.json({ error: `Match doc '${matchDocId}' not found in tournament` }, { status: 404 });
    }

    await matchRef.update({
      valorantMatchId,
      mapName,
      roundsPlayed,
      redRoundsWon: team1Rounds,
      blueRoundsWon: team2Rounds,
      playerStats,
      statsFetchedAt: new Date().toISOString(),
      apiVersion,
    });

    // ── Update player leaderboard ─────────────────────────────────────────────
    const leaderboardRef = tournamentRef.collection("leaderboard");
    const batch = adminDb.batch();

    for (const player of playerStats) {
      const playerRef = leaderboardRef.doc(player.puuid || `${player.name}-${player.tag}`);
      const existingDoc = await playerRef.get();

      if (existingDoc.exists) {
        const existing = existingDoc.data()!;
        batch.update(playerRef, {
          totalKills: (existing.totalKills || 0) + player.kills,
          totalDeaths: (existing.totalDeaths || 0) + player.deaths,
          totalAssists: (existing.totalAssists || 0) + player.assists,
          totalScore: (existing.totalScore || 0) + player.score,
          totalHeadshots: (existing.totalHeadshots || 0) + player.headshots,
          totalDamageDealt: (existing.totalDamageDealt || 0) + player.damageDealt,
          totalDamageReceived: (existing.totalDamageReceived || 0) + player.damageReceived,
          matchesPlayed: (existing.matchesPlayed || 0) + 1,
          totalRoundsPlayed: (existing.totalRoundsPlayed || 0) + roundsPlayed,
          agents: [...new Set([...(existing.agents || []), player.agent])],
          lastUpdated: new Date().toISOString(),
          // Recompute averages
          avgKills: Math.round(((existing.totalKills || 0) + player.kills) / ((existing.matchesPlayed || 0) + 1) * 100) / 100,
          avgDeaths: Math.round(((existing.totalDeaths || 0) + player.deaths) / ((existing.matchesPlayed || 0) + 1) * 100) / 100,
          kd: Math.round(((existing.totalKills || 0) + player.kills) / Math.max(1, (existing.totalDeaths || 0) + player.deaths) * 100) / 100,
          hsPercent: Math.round(((existing.totalHeadshots || 0) + player.headshots) / Math.max(1, (existing.totalHeadshots || 0) + player.headshots + (existing.totalBodyshots || 0) + player.bodyshots + (existing.totalLegshots || 0) + player.legshots) * 100),
          totalBodyshots: (existing.totalBodyshots || 0) + player.bodyshots,
          totalLegshots: (existing.totalLegshots || 0) + player.legshots,
        });
      } else {
        batch.set(playerRef, {
          puuid: player.puuid,
          name: player.name,
          tag: player.tag,
          totalKills: player.kills,
          totalDeaths: player.deaths,
          totalAssists: player.assists,
          totalScore: player.score,
          totalHeadshots: player.headshots,
          totalBodyshots: player.bodyshots,
          totalLegshots: player.legshots,
          totalDamageDealt: player.damageDealt,
          totalDamageReceived: player.damageReceived,
          matchesPlayed: 1,
          totalRoundsPlayed: roundsPlayed,
          agents: [player.agent],
          avgKills: player.kills,
          avgDeaths: player.deaths,
          kd: Math.round(player.kills / Math.max(1, player.deaths) * 100) / 100,
          hsPercent: Math.round(player.headshots / Math.max(1, player.headshots + player.bodyshots + player.legshots) * 100),
          lastUpdated: new Date().toISOString(),
        });
      }
    }

    await batch.commit();

    return NextResponse.json({
      success: true,
      apiVersion,
      map: mapName,
      roundsPlayed,
      redRounds: team1Rounds,
      blueRounds: team2Rounds,
      playersTracked: playerStats.length,
      topFragger: playerStats.sort((a, b) => b.kills - a.kills)[0]?.name || "N/A",
    });
  } catch (e: any) {
    console.error("Match fetch error:", e);
    return NextResponse.json({ error: e.message || "Server error" }, { status: 500 });
  }
}
